#!/usr/bin/env python3
"""Compile the overlay's core shaders against a real Minecraft client jar.

A core shader that fails to compile makes the client discard *every* selected
resource pack, so this has to pass before shipping a shader change.

    tools/validate-shaders.py 26.2

Downloads the client jar to a cache dir (~39 MB, official piston-data.mojang.com),
expands #moj_import the way the client does - overlay first, then the pack base,
then vanilla - and runs glslangValidator over each stage.
"""
import json, os, re, subprocess, sys, urllib.request

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.environ.get("MC_JAR_CACHE", "/tmp/mc-jars")
MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
IMPORT = re.compile(r'#moj_import\s*(?:"(.*?)"|<(.*?)>)')
# Both item_cutout and item_translucent set ALPHA_CUTOUT; check with and without
# so the shader stays valid if a pipeline stops defining it.
VARIANTS = [["ALPHA_CUTOUT 0.1"], []]


def fetch_vanilla(version):
    """Return the dir holding an extracted assets/ tree for `version`."""
    out = f"{CACHE}/{version}"
    if os.path.isdir(f"{out}/assets"):
        return out
    manifest = json.load(urllib.request.urlopen(MANIFEST))
    try:
        url = next(v["url"] for v in manifest["versions"] if v["id"] == version)
    except StopIteration:
        sys.exit(f"unknown version: {version}")
    jar_url = json.load(urllib.request.urlopen(url))["downloads"]["client"]["url"]
    os.makedirs(out, exist_ok=True)
    jar = f"{out}/client.jar"
    print(f"downloading {version} client.jar ...")
    urllib.request.urlretrieve(jar_url, jar)
    subprocess.run(["unzip", "-oq", jar, "assets/minecraft/shaders/*", "version.json",
                    "-d", out], check=True)
    return out


def make_roots(overlay, vanilla_dir):
    return [f"{REPO}/{overlay}/assets", f"{REPO}/assets", f"{vanilla_dir}/assets"]


def expand(src, roots, seen):
    out = []
    for line in src.splitlines():
        m = IMPORT.search(line)
        if not m:
            out.append(line)
            continue
        ref = m.group(1) or m.group(2)
        ns, _, path = ref.partition(":")
        if not path:
            ns, path = "minecraft", ns
        if ref in seen:                      # the client imports each file once
            continue
        seen.add(ref)
        for root in roots:
            p = f"{root}/{ns}/shaders/include/{path}"
            if os.path.exists(p):
                break
        else:
            sys.exit(f"unresolved import: {ref}")
        body = re.sub(r'^\s*#version[^\n]*\n', '', open(p).read())
        out.append(expand(body, roots, seen))
    return "\n".join(out)


def check(path, stage, defines, roots):
    head, _, rest = open(path).read().partition("\n")     # #version stays first
    text = head + "\n" + "".join(f"#define {d}\n" for d in defines) + expand(rest, roots, set())
    tmp = f"{CACHE}/expanded.{stage}"
    open(tmp, "w").write(text)
    r = subprocess.run(["glslangValidator", "-S", stage, tmp], capture_output=True, text=True)
    label = f"{os.path.basename(path)} [{' '.join(defines) or 'no defines'}]"
    print(("PASS  " if r.returncode == 0 else "FAIL  ") + label)
    if r.returncode != 0:
        print(r.stdout, r.stderr)
    return r.returncode == 0


def main():
    version = sys.argv[1] if len(sys.argv) > 1 else "26.2"
    overlay = sys.argv[2] if len(sys.argv) > 2 else "overlay_26"
    vanilla = fetch_vanilla(version)
    fmt = json.load(open(f"{vanilla}/version.json"))["pack_version"]["resource_major"]
    print(f"{version}: pack format {fmt}  (overlay {overlay})")
    roots = make_roots(overlay, vanilla)
    stages = [(f"{REPO}/{overlay}/assets/minecraft/shaders/core/item.vsh", "vert"),
              (f"{REPO}/{overlay}/assets/minecraft/shaders/core/item.fsh", "frag")]
    ok = all(check(p, s, d, roots) for d in VARIANTS for p, s in stages)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
